<?php require_once __DIR__ . '/includes/site-presentation.php'; ?>
<?php
$place = 'karnataka';
include __DIR__ . '/includes/place-page.php';
